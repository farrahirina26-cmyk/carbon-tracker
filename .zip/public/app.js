// Base API Configuration URL
const API_URL = window.location.origin + '/api';
let currentUserId=null;

// OpenStreetMap Free Dynamic Routing Setup Function Engine
async function autoCalculateDistance() {
    const start = document.getElementById('trip-start').value.trim();
    const dest = document.getElementById('trip-dest').value.trim();
    const distanceInput = document.getElementById('trip-distance');

    // Verification check: Input data validation length triggers
    if (start.length > 2 && dest.length > 2) {
        distanceInput.value = "Calculating...";
        try {
            // Geocode Starting point location nodes to Coordinates map
            const startRes = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(start)}`);
            const startData = await startRes.json();

            // Geocode Destination point location nodes to Coordinates map
            const destRes = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(dest)}`);
            const destData = await destRes.json();

            if (startData.length > 0 && destData.length > 0) {
                const lat1 = startData[0].lat;
                const lon1 = startData[0].lon;
                const lat2 = destData[0].lat;
                const lon2 = destData[0].lon;

                // Fetch Routing absolute real driving distance matrix via OSRM Server APIs
                const routeRes = await fetch(`https://router.project-osrm.org/route/v1/driving/${lon1},${lat1};${lon2},${lat2}?overview=false`);
                const routeData = await routeRes.json();

                if (routeData.routes && routeData.routes.length > 0) {
                    const distanceInKm = (routeData.routes[0].distance / 1000).toFixed(1); // Format meters unit to standard KM structure
                    distanceInput.value = distanceInKm;
                } else {
                    distanceInput.value = "5.0"; // Safe default fallback metrics
                }
            } else {
                distanceInput.value = "5.0"; // Fallback placeholder if specific landmark lookup parsing errors 
            }
        } catch (err) {
            console.error("Routing tracking engine interface failure execution logs:", err);
            distanceInput.value = "5.0";
        }
    }
}

// Attach input blurred lose focus detection listeners
document.getElementById('trip-start').addEventListener('blur', autoCalculateDistance);
document.getElementById('trip-dest').addEventListener('blur', autoCalculateDistance);

// DOM Elements Mapping
const authSection = document.getElementById('auth-section');
const dashboardSection = document.getElementById('dashboard-section');
const authForm = document.getElementById('auth-form');
const authTitle = document.getElementById('auth-title');
const nameField = document.getElementById('name-field');
const authSubmitBtn = document.getElementById('auth-submit-btn');
const authToggleBtn = document.getElementById('auth-toggle-btn');
const authToggleText = document.getElementById('auth-toggle-text');
const userDisplay = document.getElementById('user-display');
const logoutBtn = document.getElementById('logout-btn');

let isLoginMode = true;

// 1. Toggle Login/Registration Interface UI state
authToggleBtn.addEventListener('click', () => {
    isLoginMode = !isLoginMode;
    if (isLoginMode) {
        authTitle.innerText = "Account Login";
        nameField.classList.add('hidden');
        authSubmitBtn.innerText = "Login";
        authToggleText.innerText = "Don't have an account?";
        authToggleBtn.innerText = "Register Here";
    } else {
        authTitle.innerText = "Create Account";
        nameField.classList.remove('hidden');
        authSubmitBtn.innerText = "Register Now";
        authToggleText.innerText = "Already have an account?";
        authToggleBtn.innerText = "Login Here";
    }
});

// 2. Authentication Submit Pipeline (Login or Register)
authForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('auth-name').value;
    const email = document.getElementById('auth-email').value;
    const password = document.getElementById('auth-password').value;

    const endpoint = isLoginMode ? '/login' : '/register';
    const payload = isLoginMode ? { email, password } : { name, email, password };

    try {
        const res = await fetch(`${API_URL}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (!res.ok) {
            alert(data.message || 'Action execution failed.');
            return;
        }

        alert(data.message);

        if (isLoginMode) {
            currentUserId = data.user.id;
            userDisplay.innerText = `Welcome, ${data.user.name}`;
            document.getElementById('stat-eco-score').innerText = data.user.eco_score;
            
            // Switch UI Sections
            authSection.classList.add('hidden');
            dashboardSection.classList.remove('hidden');
            userDisplay.classList.remove('hidden');
            logoutBtn.classList.remove('hidden');

            // Fetch Initial user dashboard data metrics
            fetchTrips();
            fetchAnalytics();
        } else {
            // Auto switch to login view on successful register
            authToggleBtn.click();
            authForm.reset();
        }
    } catch (err) {
        console.error(err);
        alert('Server connectivity setup error.');
    }
});

// 3. Log Daily Commute Route Engine (Create Operations)
document.getElementById('trip-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
        user_id: currentUserId,
        start_point: document.getElementById('trip-start').value,
        destination: document.getElementById('trip-dest').value,
        transport_type: document.getElementById('trip-transport').value,
        distance_km: parseFloat(document.getElementById('trip-distance').value)
    };

    try {
        const res = await fetch(`${API_URL}/trips`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        if (res.ok) {
            alert('New Commute logged successfully!');
            document.getElementById('trip-form').reset();
            fetchTrips();
            fetchAnalytics();
        }
    } catch (err) {
        console.error(err);
    }
});

// 4. Read User Logs Database Rows Rendering (Read Operation)
async function fetchTrips() {
    try {
        const res = await fetch(`${API_URL}/trips/${currentUserId}`);
        const trips = await res.json();
        
        const rowsContainer = document.getElementById('trip-history-rows');
        if (trips.length === 0) {
            rowsContainer.innerHTML = `<tr><td colspan="7" class="p-4 text-center text-gray-400 italic">No trip logged yet for today.</td></tr>`;
            return;
        }

        rowsContainer.innerHTML = trips.map(trip => `
            <tr class="hover:bg-gray-50 text-gray-700 transition">
                <td class="p-2 font-medium">${trip.start_point} ➔ ${trip.destination}</td>
                <td class="p-2 capitalize"><span class="px-2 py-0.5 rounded text-xs font-semibold ${getTransportBadge(trip.transport_type)}">${trip.transport_type}</span></td>
                <td class="p-2">${trip.distance_km} KM</td>
                <td class="p-2 font-semibold text-red-500">${trip.carbon_emission_kg} kg</td>
                <td class="p-2 font-semibold text-emerald-600">+${trip.cash_saved_bdt} ৳</td>
                <td class="p-2 text-center">
                    <button onclick="deleteTrip(${trip.id})" class="text-red-500 hover:text-red-700 font-bold text-xs cursor-pointer bg-red-50 px-2 py-1 rounded">Delete</button>
                </td>
                <td class="p-2">
                     <select class="p-1 border text-xs rounded bg-white">
                         <option>⭐⭐⭐⭐⭐</option>
                         <option>⭐⭐⭐⭐</option>
                         <option>⭐⭐⭐</option>
                     </select>
                </td>
            </tr>
        `).join('');
    } catch (err) {
        console.error(err);
    }
}

// Helper Badge style controller
function getTransportBadge(type) {
    if (type === 'walk' || type === 'rickshaw' || type === 'bicycle') return 'bg-green-100 text-green-700';
    if (type === 'bus') return 'bg-teal-100 text-teal-700';
    if (type === 'bike') return 'bg-yellow-100 text-yellow-700';
    return 'bg-red-100 text-red-700';
}

// 5. Delete Commute Record (Delete Operation)
async function deleteTrip(tripId) {
    if (!confirm('Are you sure you want to drop this travel entry from database?')) return;
    try {
        const res = await fetch(`${API_URL}/trips/${tripId}`, { method: 'DELETE' });
        if (res.ok) {
            fetchTrips();
            fetchAnalytics();
        }
    } catch (err) {
        console.error(err);
    }
}

// 6. Fetch Aggregate Summary & Smart Expert Recommendations (Read & Logic Engine)
async function fetchAnalytics() {
    try {
        const res = await fetch(`${API_URL}/analytics/${currentUserId}`);
        const data = await res.json();

        document.getElementById('stat-total-trips').innerText = data.summary.total_trips;
        document.getElementById('stat-total-carbon').innerText = `${data.summary.total_carbon_kg} kg`;
        document.getElementById('stat-total-savings').innerText = `${data.summary.total_cash_saved_bdt} ৳`;
        
        // Smart decision content mapping update
        document.getElementById('smart-suggestion-text').innerHTML = `
            <strong class="text-emerald-800">[${data.smart_decision.status}]</strong> ${data.smart_decision.suggestion}
        `;
    } catch (err) {
        console.error(err);
    }
}

// ========================================================
// 💬 COMMUNITY FEEDBACK ROUTING ACTION (FIXED)
// ========================================================
const communityBtn = document.getElementById('community-btn');
if (communityBtn) {
    // বাটনে ক্লিক করলে সরাসরি কমিউনিটি পেজে নিয়ে যাবে
    communityBtn.addEventListener('click', () => {
        window.location.href = '/community';
    });
}

// 7. Logout Pipeline Action
logoutBtn.addEventListener('click', () => {
    window.location.reload();
});

// ========================================================
// 🏠 8. Log Household Consumption Engine (Home Carbon - UI Update)
// ========================================================
const homeFormBox = document.getElementById('home-form');
if (homeFormBox) {
    homeFormBox.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (typeof currentUserId === 'undefined' || !currentUserId) {
            alert("Session khuje paoya jacche na! Kosto kore arekbar login page theke login korun.");
            return;
        }
        
        const payload = {
            user_id: currentUserId,
            lights: parseInt(document.getElementById('home-lights').value) || 0,
            fans: parseInt(document.getElementById('home-fans').value) || 0,
            acs: parseInt(document.getElementById('home-acs').value) || 0,
            devices: parseInt(document.getElementById('home-devices').value) || 0
        };

        try {
            const res = await fetch(`${API_URL}/home-consumption`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            
            const data = await res.json();
            
            if (res.ok) {
                // পপ-আপ বন্ধ করে সরাসরি HTML বক্সে ডাটা শো করানো
                const resultBox = document.getElementById('home-result-box');
                const resultCo2 = document.getElementById('home-result-co2');
                
                if (resultBox && resultCo2) {
                    const totalCarbon = data.total_home_carbon ? data.total_home_carbon.toFixed(2) : 0;
                    resultCo2.innerText = totalCarbon;
                    
                    // হিডেন বক্সটি ভিজিবল করা
                    resultBox.classList.remove('hidden');
                }
                
                // মূল ড্যাশবোর্ড কাউন্টার আপডেট
                if (typeof fetchAnalytics === 'function') {
                    fetchAnalytics(); 
                }
            } else {
                alert(data.message || "Backend error in calculation logic!");
            }
        } catch (err) {
            console.error("Network endpoint connection error:", err);
            alert("Server connection fail hoyeche! Node console check korun.");
        }
    });
}