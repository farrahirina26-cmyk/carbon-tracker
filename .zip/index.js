const express = require('express');
const path = require('path'); 
const cors = require('cors');
const db = require('./db'); // Database import
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json()); 
app.use(express.urlencoded({ extended: true }));
app.use(cors());

app.use(express.static('public'));

// Test Route with DB Connection Check
app.get('/', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT 1 + 1 AS result');
        res.send(`Carbon Footprint Tracker Server is Running! Database Connected Successfully.`);
    } catch (err) {
        console.error(err);
        res.status(500).send('Server is running, but Database Connection Failed!');
    }
});

const bcrypt = require('bcryptjs');

// 1. REGISTER ROUTE
app.post('/api/register', async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ message: 'Shob field fill-up korun!' });
    }
    try {
        const [existingUser] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        if (existingUser.length > 0) {
            return res.status(400).json({ message: 'Ei email diye account already ache!' });
        }
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);
        await db.query(
            'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
            [name, email, hashedPassword]
        );
        res.status(201).json({ message: 'Registration successfully completed!' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server-e kono shomoshya hoyeche!' });
    }
});

// 2. LOGIN ROUTE
app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ message: 'Email ebong password dutoই lagbe!' });
    }
    try {
        const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        if (users.length === 0) {
            return res.status(400).json({ message: 'User paoya jayni! Valid email din.' });
        }
        const user = users[0];
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Password thik nai!' });
        }
        res.status(200).json({
            message: 'Login successfully completed!',
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                eco_score: user.eco_score
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server-e kono shomoshya hoyeche!' });
    }
});

// 3. ADD NEW TRIP
app.post('/api/trips', async (req, res) => {
    const { user_id, start_point, destination, transport_type, distance_km } = req.body;
    if (!user_id || !start_point || !destination || !transport_type || !distance_km) {
        return res.status(400).json({ message: 'Shob elements fill-up kora baddhotamulok!' });
    }
    let emissionFactor = 0; 
    let alternativeCostPerKm = 30; 
    let currentTransportCostPerKm = 0;

    switch (transport_type.toLowerCase()) {
        case 'car':
            emissionFactor = 0.18;
            currentTransportCostPerKm = 30;
            break;
        case 'bike':
            emissionFactor = 0.10;
            currentTransportCostPerKm = 15;
            break;
        case 'bus':
            emissionFactor = 0.05;
            currentTransportCostPerKm = 5;
            break;
        case 'rickshaw':
        case 'walk':
        case 'bicycle':
            emissionFactor = 0.00;
            currentTransportCostPerKm = 0;
            break;
        default:
            emissionFactor = 0.08; 
            currentTransportCostPerKm = 10;
    }

    const totalEmission = distance_km * emissionFactor;
    const totalCashSaved = (alternativeCostPerKm * distance_km) - (currentTransportCostPerKm * distance_km);

    try {
        const [result] = await db.query(
            'INSERT INTO trips (user_id, start_point, destination, transport_type, distance_km, carbon_emission_kg, cash_saved_bdt) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [user_id, start_point, destination, transport_type, distance_km, totalEmission, totalCashSaved]
        );
        if (totalEmission === 0) {
            await db.query('UPDATE users SET eco_score = eco_score + 10 WHERE id = ?', [user_id]);
        } else if (totalEmission > 1.0) {
            await db.query('UPDATE users SET eco_score = eco_score - 5 WHERE id = ?', [user_id]);
        }
        res.status(201).json({
            message: 'Trip added successfully!',
            tripId: result.insertId,
            carbon_emission: totalEmission,
            cash_saved: totalCashSaved
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Trip add korte backend table-e problem hoyeche!' });
    }
});

// 4. GET ALL TRIPS
app.get('/api/trips/:user_id', async (req, res) => {
    const { user_id } = req.params;
    try {
        const [rows] = await db.query(
            'SELECT * FROM trips WHERE user_id = ? ORDER BY created_at DESC', 
            [user_id]
        );
        res.status(200).json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Trips data fetch korte problem hoyeche!' });
    }
});

// 5. DELETE A TRIP
app.delete('/api/trips/:trip_id', async (req, res) => {
    const { trip_id } = req.params;
    try {
        const [result] = await db.query('DELETE FROM trips WHERE id = ?', [trip_id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Ei id-r kono trip paoya jayni!' });
        }
        res.status(200).json({ message: 'Trip deleted successfully!' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Trip delete korte backend-e error hoyeche!' });
    }
});

// 6. ANALYTICS
app.get('/api/analytics/:user_id', async (req, res) => {
    const { user_id } = req.params;
    try {
        const [stats] = await db.query(
            `SELECT 
                SUM(carbon_emission_kg) AS total_carbon, 
                SUM(cash_saved_bdt) AS total_savings,
                COUNT(id) AS total_trips
             FROM trips WHERE user_id = ?`, 
            [user_id]
        );
        const [frequentTransport] = await db.query(
            `SELECT transport_type, COUNT(id) AS count 
             FROM trips WHERE user_id = ? 
             GROUP BY transport_type 
             ORDER BY count DESC LIMIT 1`,
            [user_id]
        );

        const totalCarbon = parseFloat(stats[0].total_carbon) || 0;
        const totalSavings = parseFloat(stats[0].total_savings) || 0;
        const totalTrips = stats[0].total_trips || 0;
        const mainTransport = frequentTransport.length > 0 ? frequentTransport[0].transport_type.toLowerCase() : 'none';

        let dynamicSuggestion = "";
        let ecoScoreStatus = "";

        if (totalCarbon > 20) {
            dynamicSuggestion = "Apnar carbon footprint tracking level dher beshi! Agami trip gulo-te Bike ba Car er poriborte Bus ba Walking options prefer korun.";
            ecoScoreStatus = "Alert: High Emission Risk";
        } else if (mainTransport === 'bike' || mainTransport === 'car') {
            dynamicSuggestion = "Apni beshirbhag shomoy private transport use korchen. Saptah-e kormopokkhe 2 din public bus ba rickshaw use korle apnar cash savings 30% briddhi pabe.";
            ecoScoreStatus = "Moderate Efficiency";
        } else {
            dynamicSuggestion = "Chomotkar! Apnar environmental footprint ekhon control-e ache. Sustainable local travel-er ei dhara bojay rakhun.";
            ecoScoreStatus = "Excellent Eco-Warrior";
        }

        res.status(200).json({
            summary: {
                total_trips: totalTrips,
                total_carbon_kg: totalCarbon.toFixed(2),
                total_cash_saved_bdt: totalSavings.toFixed(2)
            },
            smart_decision: {
                status: ecoScoreStatus,
                suggestion: dynamicSuggestion
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Analytics data compile korte syntax error hoyeche!' });
    }
});

// 7. HOME CONSUMPTION LOGGER API
app.post('/api/home-consumption', async (req, res) => {
    const { user_id, lights, fans, acs, devices } = req.body;
    const lightsCount = parseInt(lights) || 0;
    const fansCount = parseInt(fans) || 0;
    const acCount = parseInt(acs) || 0;
    const devicesCount = parseInt(devices) || 0;

    if (!user_id) {
        return res.status(400).json({ message: 'User ID baddhotamulok!' });
    }

    const lightRate = 0.15;
    const fanRate = 0.40;
    const acRate = 2.50;
    const deviceRate = 0.30;

    const totalHomeCarbon = (lightsCount * lightRate) + 
                            (fansCount * fanRate) + 
                            (acCount * acRate) + 
                            (devicesCount * deviceRate);

    try {
        const [result] = await db.query(
            'INSERT INTO home_consumption (user_id, lights_count, fans_count, ac_count, devices_count, total_home_carbon_kg) VALUES (?, ?, ?, ?, ?, ?)',
            [user_id, lightsCount, fansCount, acCount, devicesCount, totalHomeCarbon]
        );
        if (totalHomeCarbon > 2.0) {
            await db.query('UPDATE users SET eco_score = eco_score - 5 WHERE id = ?', [user_id]);
        } else {
            await db.query('UPDATE users SET eco_score = eco_score + 5 WHERE id = ?', [user_id]);
        }
        res.status(201).json({
            message: 'Household consumption logged successfully!',
            logId: result.insertId,
            total_home_carbon: totalHomeCarbon
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Home consumption entry database-e save korte problem hoyeche!' });
    }
});

// ========================================================
// 💬 COMMUNITY FEEDBACK & RATINGS API ROUTES (FIXED ASYNC/AWAIT)
// ========================================================

// ১. নতুন ফিডব্যাক ডাটাবেজে সেভ করার রাউট (POST)
app.post('/api/feedback', async (req, res) => {
    const { user_id, user_name, rating, comment } = req.body;
    
    if (!rating || !comment) {
        return res.status(400).json({ status: "error", message: "Rating and comment are required!" });
    }

    try {
        const query = "INSERT INTO feedbacks (user_id, user_name, rating, comment) VALUES (?, ?, ?, ?)";
        await db.query(query, [user_id || 1, user_name || 'Nadia Ahmed', rating, comment]);
        
        console.log("✅ New feedback inserted into DB!");
        return res.status(200).json({ status: "success", message: "Feedback saved!" });
    } catch (err) {
        console.error("❌ Database insertion failed:", err);
        return res.status(500).json({ status: "error", message: "Database insertion failed" });
    }
});

// ২. ডাটাবেজ থেকে সব ফিডব্যাক নিয়ে আসার রাউট (GET)
app.get('/api/feedback', async (req, res) => {
    try {
        const query = "SELECT user_name, rating, comment, created_at FROM feedbacks ORDER BY created_at DESC";
        const [results] = await db.query(query);
        return res.status(200).json(results);
    } catch (err) {
        console.error("❌ Database fetch failed:", err);
        return res.status(500).json({ status: "error", message: "Failed to load reviews" });
    }
});

// ৩. কমিউনিটি পেজের HTML ফাইল সার্ভ করার রুট
app.get('/community', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'community.html'));
});

app.listen(PORT, () => {
    console.log(`Server is spinning on port ${PORT}`);
});